﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebSite.Controllers
{
    public class AboutController : Controller
    {
        // GET: about
        public ActionResult About()
        {
            return View();
        }
    }
}