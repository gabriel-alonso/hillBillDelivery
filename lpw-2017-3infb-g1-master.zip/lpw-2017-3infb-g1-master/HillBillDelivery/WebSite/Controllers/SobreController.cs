﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebSite.Controllers
{
    public class SobreController : Controller
    {


        //AÇÕES
        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult WorkTeam()
        {
            return View();
        }
        public ActionResult OurOffers()
        {
            return View();
        }
        public ActionResult Contatos()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Menu()
        {
            return View();
        }
        public ActionResult Codes()
        {
            return View();
        }
        public ActionResult NewsEvents()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
    }
}