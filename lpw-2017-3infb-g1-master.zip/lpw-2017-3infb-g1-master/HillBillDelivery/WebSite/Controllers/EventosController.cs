﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebSite.Controllers
{
    public class EventosController : Controller
    {
        // GET: Eventos
        public ActionResult Noticia1()
        {
            return View();
        }
        public ActionResult Noticia2()
        {
            return View();
        }
        public ActionResult Noticia3()
        {
            return View();
        }
        public ActionResult Evento()
        {
            return View();
        }
    }
}